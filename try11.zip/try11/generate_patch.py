from openslide import open_slide, __library_version__ as openslide_lib_version, __version__ as openslide_version
import numpy as np
import random, os, glob, time
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from skimage.color import rgb2hsv
import pandas as pd

def read_slide(slide, x, y, level, width, height, as_float=False):
    """ Read a region from the slide
    Return a numpy RBG array
    """
    im = slide.read_region((x, y), level, (width, height))
    im = im.convert('RGB')  # drop the alpha channel
    if as_float:
        im = np.asarray(im, dtype=np.float32)
    else:
        im = np.asarray(im)
    assert im.shape == (height, width, 3)  # 3：rgb
    return im


def find_tissue_pixels(image):
    """ Return tissue pixels for an image
    """
    img_RGB = np.array(image)
    img_HSV = rgb2hsv(img_RGB)
    #background_R = img_RGB[:, :, 0] > 203
    #background_G = img_RGB[:, :, 1] > 191
    #background_B = img_RGB[:, :, 2] > 201
    #tissue_RGB = np.logical_not(background_R & background_G & background_B)
    tissue_S = img_HSV[:, :, 1] > 0.07
    tissue_V = img_HSV[:, :, 2] < 0.1
    '''如果仅使用用threadshold，中间会有部份白色脂肪区域被隔离'''
    #rgb_min = 50
    #min_R = img_RGB[:, :, 0] > rgb_min
    #min_G = img_RGB[:, :, 1] > rgb_min
    #min_B = img_RGB[:, :, 2] > rgb_min
    tissue_mask = tissue_S & tissue_V
    indices = np.where(tissue_mask == 1)
    return zip(indices[0], indices[1])


def apply_mask(im, mask, color=(1, 0, 0)):
    """ Return the mask as an image
    """
    masked = np.zeros(im.shape)
    for x, y in mask: masked[x][y] = color
    return masked


def get_patches(slide, tumor_mask, lev, x0, y0, patch_size):
    """ Get patches from a slide: RBG image, tumor mask, tissue mask CENTERED at x0, y0
    imputs:
    - slide: OpenSlide object for RGB slide images
    - tumor_mask: OpenSlide object for tumor masks
    - lev: int, target zoom level for the patches, between 0 and 7
    - x0, y0: int, pixel coordinates at level 0
    - patch_size: int, usually 299
    outputs:
    - patch_image: array, RBG image
    - patch_mask: array, tumor mask
    - patch_tissue: array, tissue mask
    """

    # calc downsample factor
    downsample_factor = 2 ** lev

    # calc new x and y so that the patch is CENTER at the input x and y
    new_x = x0 - (patch_size // 2) * downsample_factor
    new_y = y0 - (patch_size // 2) * downsample_factor

    # read RGB patch
    patch_image = read_slide(slide,
                             x=new_x,
                             y=new_y,
                             level=lev,
                             width=patch_size,
                             height=patch_size)

    # read tumor mask
    patch_mask = read_slide(tumor_mask,
                            x=new_x,
                            y=new_y,
                            level=lev,
                            width=patch_size,
                            height=patch_size)

    # 1 channel is enough for the mask
    patch_mask = patch_mask[:, :, 0]

    # make tissue mask
    tissue_pixels = find_tissue_pixels(patch_image)
    patch_tissue = apply_mask(patch_image, tissue_pixels)

    return patch_image, patch_mask, patch_tissue


def check_patch_centre(patch_mask, patch_centre):
    """ Check if there is any tumor pixel in the 128x128 centre
    inputs:
    - patch_mask: array, tumor mask
    - patch_centre: int, usually 128
    outputs: Boolean
    """

    # get patch size
    patch_size = patch_mask.shape[0]

    # get the offset to check the 128x128 centre
    offset = int((patch_size - patch_centre) / 2)

    # sum the pixels in the 128x128 centre for the tumor mask
    sum_cancers = np.sum(patch_mask[offset:offset + patch_centre, offset:offset + patch_centre])

    return sum_cancers > 0