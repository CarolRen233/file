import sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(BASE_DIR)
from openslide import OpenSlide, OpenSlideUnsupportedFormatError
import cv2, glob, tqdm
import numpy as np
import pandas as pd
import logging
from classfication.preprocess.wsi_ops import wsi
from classfication.utils.config import TRAINSET, MASK_FOLDER, TESTSET
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, ALL_COMPLETED
import concurrent.futures
import argparse
import matplotlib.pyplot as plt
from skimage.filters import threshold_otsu


def Label(mask, w, h, level, win):
    '''
    :param w,h: center point in level 0
    :param level:
    :param win: in level 0
    :param mask:OpenSlide
    :return:
    '''
    if mask == 0:
        return mask
    assert isinstance(mask, OpenSlide)
    mask = wsi.read_slide(mask, w, h, level, win, win)
    return int(mask.sum() > 0)


def skip_slide(slide_name):
    skip_list = ['normal_86', 'normal_144', 'test_049', 'test_114']
    for skip_name in skip_list:
        if skip_name in slide_name:
            return True
    return False


def extract_tumor(slide_name):
    skip_list = []
    return True


class ExtractPatch:
    def __init__(self, tif_folder, mask_folder, level, save_path, win_size, StepSize=64, grid_size=256, otsu_level=0,
                 white_thred=0.1):
        r'''
        Use pandas.Framework to save result
        :param otsu_folder: contain tumor_001.npy
        :param mask_folder: contain mask.tif
        :param level: otsu level
        :param save_path:
        :param win_size:
        '''
        # assert (os.path.exists(tif_folder) or os.path.exists(otsu_folder)) and os.path.exists(mask_folder)==True
        self.tif_folder = tif_folder
        self.mask_folder = mask_folder
        self.level = level
        self.step_size = StepSize
        self.grid_size = grid_size
        self.save_path = save_path
        self.win_size = win_size
        self._load_mask()
        self.otsu_level = otsu_level
        self._load_tif()
        self.white_thred = 0.1

    def _load_mask(self):
        self.mask_dict = {}
        pbar = tqdm.tqdm(glob.glob(os.path.join(self.mask_folder, '*.tif')))
        for gt_mask in pbar:
            if skip_slide(gt_mask):
                continue
            _basename = os.path.basename(gt_mask).rstrip('.tif')
            pbar.set_description(f"Processing mask {gt_mask} - {_basename}")
            self.mask_dict[_basename] = gt_mask

    def _load_tif(self):
        logging.info('detecting ROI')
        self.tifs = {}
        pbar = tqdm.tqdm(glob.glob(self.tif_folder + '/*/*.tif'))
        for tif in pbar:
            if skip_slide(tif):
                continue
            _basename = os.path.basename(tif).rstrip('.tif')
            pbar.set_description(f"Processing tif {tif} - {_basename}")
            args.tifs[_basename] = tif


def extract_from_single_slide(slidename):
    '''
    Sample Patch with limited stride for tissue
    :param slide:
    read_slide: return im (height, width X C)
    :return: stats about patch points
    '''
    # logging.info(f'extract samples from{slide}')
    stats = {0: 0, 1: 0}
    save = os.path.join(args.save_path, f'{slidename}.csv')
    if os.path.exists(save):
        table = pd.read_csv(save, index_col=0, header=0)
        stats[0] = (table['label'] == 0).sum()
        stats[1] = (table['label'] == 1).sum()
        return stats
    table = pd.DataFrame(columns=['slide_name', 'x', 'y', 'label'])

    count = 0
    try:
        mask = OpenSlide(mask_dict[slidename])
    except:
        logging.info(f'mask {slidename} not exists!!')
        mask = 0
    slide = OpenSlide(tifs[slidename])
    W, H = slide.dimensions
    x_center = args.grid_size // 2
    for col in range(int((W - args.grid_size / 2) // args.step_size)):
        y_center = args.grid_size // 2
        for row in range(int((H - args.grid_size / 2) // args.step_size)):
            otsu, white_flag = wsi.read_otsu(slide, x_center, y_center, args.otsu_level, args.win_size,
                                             args.win_size, args.white_thred)
            label = Label(mask, x_center, y_center, args.level, win=args.win_size)
            if white_flag or label:
                table.loc[count] = (slidename, x_center, y_center, label)
                count += 1
                stats[label] += 1
            y_center += args.step_size
        x_center += args.step_size

    logging.info(f'samples {str(stats)} from {slidename} done!!')
    if mask != 0 and stats[1] == 0:
        logging.warning(f'{slidename} cannot find tumor')
    table.to_csv(save, header=True)
    return stats

def extract_test_from_single_slide(slidename):
    '''
    Sample Patch with limited stride for tissue
    :param slide:
    read_slide: return im (height, width X C)
    :return: stats about patch points
    '''
    # logging.info(f'extract samples from{slide}')
    stats = {0: 0, 1: 0}
    save = os.path.join(args.save_path, f'{slidename}.csv')
    if os.path.exists(save):
        table = pd.read_csv(save, index_col=0, header=0)
        stats[0] = (table['label'] == 0).sum()
        stats[1] = (table['label'] == 1).sum()
        return stats
    table = pd.DataFrame(columns=['slide_name', 'x', 'y', 'label'])

    count = 0
    try:
        mask = OpenSlide(mask_dict[slidename])
    except:
        logging.info(f'mask {slidename} not exists!!')
        mask = 0
    slide = OpenSlide(tifs[slidename])
    W, H = slide.dimensions
    x_center = args.grid_size // 2
    while (x_center + args.grid_size / 2 < W):
        y_center = args.grid_size // 2
        while (y_center + args.grid_size / 2 < H):
            otsu, white_flag = wsi.read_otsu(slide, x_center, y_center, args.otsu_level, args.win_size,
                                             args.win_size, args.white_thred)
            label = Label(mask, x_center, y_center, args.level, win=args.win_size)
            if white_flag or label:
                table.loc[count] = (slidename, x_center, y_center, label)
                count += 1
                stats[label] += 1
                y_center += args.grid_size
            else:
                y_center += args.step_size
        x_center += args.grid_size
    logging.info(f'samples {str(stats)} from {slidename} done!!')
    if mask != 0 and stats[1] == 0:
        logging.warning(f'{slidename} cannot find tumor')
    table.to_csv(save, header=True)
    return stats


parser = argparse.ArgumentParser()
parser.add_argument("-n", "--num_works", type=int, default=1, help='num of workers')
parser.add_argument("-ol", '--otsu_level', type=int, default=0, help="otsu level")
parser.add_argument("-l", '--level', type=int, default=0, help="work level")
parser.add_argument("-mf", "--mask_folder", type=str, default=MASK_FOLDER, help="Mask folder")
parser.add_argument("-w", "--win_size", default=128, type=int, help="win size in level 0")
parser.add_argument("-ss", "--step_size", default=256, type=int, help="stride in level 0")
parser.add_argument("-g", "--grid_size", default=384,type=int, help="grid_size,as same as win size proposed")
parser.add_argument("-t", "--test",default='train', type=str, help="test or train")
parser.add_argument("-s", "--save_path", default='/userhome/', type=str, help="save path")




def run(args):
    if not os.path.exists(args.save_path):
        os.mkdir(args.save_path)
    logging.basicConfig(level=logging.INFO, filename=os.path.join(args.save_path, 'patch_generate_log.txt'))
    logging.info(str(args))
    if args.test == 'train':
        tif_folder = TRAINSET
    elif args.test == 'test':
        tif_folder = TESTSET
    # load mask
    mask_dict = {}
    pbar = tqdm.tqdm(glob.glob(os.path.join(args.mask_folder, '*.tif')))
    for gt_mask in pbar:
        if skip_slide(gt_mask):
                continue
        basename = os.path.basename(gt_mask).rstrip('.tif')
        pbar.set_description(f"Processing mask {gt_mask} - {_basename}")
        mask_dict[basename] = gt_mask
    #load tif
    tifs = {}
    pbar = tqdm.tqdm(glob.glob(args.tif_folder + '/*/*.tif'))
    for tif in pbar:
        if skip_slide(tif):
            continue
        basename = os.path.basename(tif).rstrip('.tif')
        pbar.set_description(f"Processing tif {tif} - {basename}")
        tifs[basename] = tif




def main():
    args = parser.parse_args()
    run(args)


if __name__ == '__main__':
    main()