import os, glob, torch
import openslide
import logging
import numpy as np
import math, random
from torchvision import transforms
from classfication.preprocess.wsi_ops import wsi
from classfication.preprocess.annotation import Annotation
from PIL import Image
import pandas as pd


class MaskDataset():
    def __init__(self, tif_folder, mask_folder, level, patch_size, crop_size, table, rotate=-1, flip=None):
        """
        Dataset for Mask
        :param list_file: cords file. tif_name,x,y
        :param tif_folder: /Camelyonfolder/
        :param mask_folder: /CamelyonMaskfolder/
        :param level:
        :param patch_size: patch_size
        """
        self.table = table
        self.tif_folder = tif_folder
        self.mask_folder = mask_folder
        self.level = level
        self.patch_size = patch_size
        self.crop_size = crop_size
        self._totensor = transforms.ToTensor()
        self._color_jitter = transforms.ColorJitter(64.0 / 255, 0.75, 0.25, 0.04)
        self._preprocess()
        self._flip = flip
        self._rotate = rotate

    def _preprocess(self):
        tif_list = glob.glob(os.path.join(self.tif_folder, '*/*.tif'))
        if tif_list == []:
            raise ValueError('tif folder should include tif files.')
        logging.info(f"loading tifs from {self.tif_folder}")
        mask_list = glob.glob(os.path.join(self.mask_folder, '*/*.tif'))
        if mask_list == []:
            raise ValueError('mask folder should include mask files(.tif).')
        self.patch_size = self.patch_size
        self.level = self.level
        # 添加所有的slide缓存，从缓存中取数据
        self.slide_dict = {}
        for tif in tif_list:
            basename = os.path.basename(tif).rstrip('.tif')
            self.slide_dict[basename] = openslide.OpenSlide(tif)
        self.mask_dict = {}
        for mask in mask_list:
            basename = os.path.basename(mask).rstrip('.tif')
            self.mask_dict[basename] = openslide.OpenSlide(mask)

    def __len__(self):
        """

        :param self:
        :return: length of cords
        """
        return self.table.shape[0]

    def __getitem__(self, index):
        '''
        :param index:
        :return: img (C x H x W),target
        '''
        slide_name, _x, _y, _ = self.table.loc[index]
        slide = self.slide_dict[slide_name]
        img = wsi.read_slide(slide, _x, _y, self.level, self.patch_size, self.patch_size)  # numpy.array
        try:
            mask = self.mask_dict[slide_name]
            target = wsi.read_slide(mask, _x, _y, self.level, self.patch_size, self.patch_size)  # numpy.array
        except:
            target = np.zeros_like(img)
        # data augmentation
        img = Image.fromarray(img)
        target = Image.fromarray(target)
        img, target = self._random_crop(img, target)
        img = self._color_jitter(img)
        if self._flip:
            img = img.transpose(Image.FLIP_LEFT_RIGHT)
            target = img.transpose(Image.FLIP_LEFT_RIGHT)
        img, target = self._random_rotate(img, target)
        # 取最后一个通道
        img, target = self._totensor(img), self._totensor(target)[0, :, :]
        return img, target, index

    def _random_rotate(self, img, target):
        if self._rotate == -1:
            num_rotate = np.random.randint(0, 4)
        else:
            num_rotate = self._rotate
        img = img.rotate(90 * num_rotate)
        target = target.rotate(90 * num_rotate)
        return img, target

    def _random_crop(self, img, target):
        '''

        :param img: PIL
        :param target: PIL
        :return:
        '''
        xloc = np.random.randint(0, self.patch_size - self.crop_size)
        yloc = np.random.randint(0, self.patch_size - self.crop_size)
        img = img.crop((xloc, yloc, xloc + self.crop_size, yloc + self.crop_size))
        target = target.crop((xloc, yloc, xloc + self.crop_size, yloc + self.crop_size))
        return img, target


class ListDataset():
    def __init__(self, tif_folder, mask_folder, level, patch_size, crop_size, table, rotate=-1, flip=0):
        '''

        :param list_file:
        :param tif_folder:
        :param mask_folder:
        :param level:
        :param patch_size:
        :param crop_size:
        '''
        self.table = table
        self.tif_folder = os.path.abspath(tif_folder)
        self.mask_folder = mask_folder
        self.level = level
        self.patch_size = patch_size
        self.crop_size = crop_size
        self._preprocess()
        self._totensor = transforms.ToTensor()
        self._color_jitter = transforms.ColorJitter(brightness=64.0 / 255, contrast=0.75, saturation=0.25, hue=0.04)
        self._flip = flip
        self._rotate = rotate

    def __len__(self):
        """

        :param self:
        :return: length of cords
        """
        return self.table.shape[0]

    def _preprocess(self):
        '''

        :return:
        '''

        tif_list = glob.glob(os.path.join(self.tif_folder, '*/*.tif'))
        if tif_list == []:
            raise ValueError('tif folder should include tif files.')
        logging.info(f"loading tifs from {self.tif_folder}")
        # 添加所有的slide缓存，从缓存中取数据
        self.slide_dict = {}
        for tif in tif_list:
            basename = os.path.basename(tif).rstrip('.tif')
            self.slide_dict[basename] = tif
            self.slide_dict[basename] = openslide.OpenSlide(tif)

    def __getitem__(self, item):
        slide_name, _x, _y, target = self.table.loc[item]
        slide = self.slide_dict[slide_name]
        # try:
        #     slide = openslide.OpenSlide(self.slide_dict[slide_name])
        # except:
        #     raise ValueError(f'{slide_name}.tif not exists!, index {item}')
        img = wsi.read_slide(slide, _x, _y, self.level, self.patch_size, self.patch_size)
        img = Image.fromarray(img)
        if self._flip and np.random.ranf()<0.5:
            img = img.transpose(Image.FLIP_LEFT_RIGHT)
        img = self._random_crop(img)
        img = self._color_jitter(img)
        img = self._random_rotate(img)
        img = self._totensor(img)
        return img, target, item

    def _random_crop(self, img):
        '''

        :param img: PIL
        :param target: PIL
        :return:
        '''
        if self.patch_size - self.crop_size:
            xloc = np.random.randint(0, self.patch_size - self.crop_size)
            yloc = np.random.randint(0, self.patch_size - self.crop_size)
            img = img.crop((xloc, yloc, xloc + self.crop_size, yloc + self.crop_size))
        return img

    def _random_rotate(self, img):
        if self._rotate == -1:
            num_rotate = np.random.randint(0, 4)
        num_rotate = self._rotate
        img = img.rotate(90 * num_rotate)
        return img



class GridImageDataset():
    """
    Data producer that generate a square grid, e.g. 3x3, of patches and their
    corresponding labels from pre-sampled images.
    """
    def __init__(self, tif_folder, json_path, table, img_size=768, patch_size=256,
                 crop_size=224, normalize=True):
        """
        Initialize the data producer.
        Arguments:
            data_path: string, path to pre-sampled images using patch_gen.py
            json_path: string, path to the annotations in json format
            img_size: int, size of pre-sampled images, e.g. 768
            patch_size: int, size of the patch, e.g. 256
            crop_size: int, size of the final crop that is feed into a CNN,
                e.g. 224 for ResNet
            normalize: bool, if normalize the [0, 255] pixel values to [-1, 1],
                mostly False for debuging purpose
        """
        self.tif_folder = tif_folder
        self.table = table
        self._json_path = json_path
        self._img_size = img_size
        self._patch_size = patch_size
        self._crop_size = crop_size
        self._normalize = normalize
        self._color_jitter = transforms.ColorJitter(64.0/255, 0.75, 0.25, 0.04)
        self._preprocess()

    def _preprocess(self):
        if self._img_size % self._patch_size != 0:
            raise Exception('Image size / patch size != 0 : {} / {}'.
                            format(self._img_size, self._patch_size))

        self._patch_per_side = self._img_size // self._patch_size
        self._grid_size = self._patch_per_side * self._patch_per_side

        self._pids = list(map(lambda x: x.rstrip('.json'),
                        [i for i in os.listdir(self._json_path) if i.endswith('.json')]))

        self._annotations = {}
        for pid in self._pids:
            pid_json_path = os.path.join(self._json_path, pid + '.json')
            anno = Annotation()
            anno.from_json(pid_json_path)
            self._annotations[pid] = anno
        # load tif
        tif_list = glob.glob(os.path.join(self.tif_folder, '*/*.tif'))
        if tif_list == []:
            raise ValueError('tif folder should include tif files.')
        logging.info(f"loading tifs from {self.tif_folder}")
        # 添加所有的slide缓存，从缓存中取数据
        self.slide_dict = {}
        for tif in tif_list:
            basename = os.path.basename(tif).rstrip('.tif')
            self.slide_dict[basename] = tif
            self.slide_dict[basename] = openslide.OpenSlide(tif)


    def __len__(self):
        return self.table.shape[0]

    def __getitem__(self, idx):
        pid, x_center, y_center,_ = self.table.loc[idx]
        slide = self.slide_dict[pid]
        x_top_left = int(x_center - self._img_size / 2)
        y_top_left = int(y_center - self._img_size / 2)

        # the grid of labels for each patch
        label_grid = np.zeros((self._patch_per_side, self._patch_per_side),
                              dtype=np.float32)
        for x_idx in range(self._patch_per_side):
            for y_idx in range(self._patch_per_side):
                # (x, y) is the center of each patch
                x = x_top_left + int((x_idx + 0.5) * self._patch_size)
                y = y_top_left + int((y_idx + 0.5) * self._patch_size)

                if self._annotations[pid].inside_polygons((x, y), True):
                    label = 1
                else:
                    label = 0

                # extracted images from WSI is transposed with respect to
                # the original WSI (x, y)
                label_grid[y_idx, x_idx] = label

        img = wsi.read_slide(slide, x_top_left, y_top_left, 0, self._img_size, self._img_size)
        img = Image.fromarray(img)
        # color jitter
        img = self._color_jitter(img)

        # use left_right flip
        if np.random.rand() > 0.5:
            img = img.transpose(Image.FLIP_LEFT_RIGHT)
            label_grid = np.fliplr(label_grid)

        # use rotate
        num_rotate = np.random.randint(0, 4)
        img = img.rotate(90 * num_rotate)
        label_grid = np.rot90(label_grid, num_rotate)

        # PIL image:   H x W x C
        # torch image: C X H X W
        img = np.array(img, dtype=np.float32).transpose((2, 0, 1))

        if self._normalize:
            img = (img - 128.0)/128.0

        # flatten the square grid
        img_flat = np.zeros(
            (self._grid_size, 3, self._crop_size, self._crop_size),
            dtype=np.float32)
        label_flat = np.zeros(self._grid_size, dtype=np.float32)

        idx = 0
        for x_idx in range(self._patch_per_side):
            for y_idx in range(self._patch_per_side):
                # center crop each patch
                x_start = int(
                    (x_idx + 0.5) * self._patch_size - self._crop_size / 2)
                x_end = x_start + self._crop_size
                y_start = int(
                    (y_idx + 0.5) * self._patch_size - self._crop_size / 2)
                y_end = y_start + self._crop_size
                img_flat[idx] = img[:, x_start:x_end, y_start:y_end]
                label_flat[idx] = label_grid[x_idx, y_idx]

                idx += 1

        return (img_flat, label_flat)

import numpy as np
from torch.utils.data import Dataset
import openslide
import PIL

np.random.seed(0)


class GridWSIPatchDataset(Dataset):
    """
    Data producer that generate all the square grids, e.g. 3x3, of patches,
    from a WSI and its tissue mask, and their corresponding indices with
    respect to the tissue mask
    """
    def __init__(self, wsi_path, mask_path, image_size=768, patch_size=256,
                 crop_size=224, normalize=True, flip='NONE', rotate='NONE'):
        """
        Initialize the data producer.
        Arguments:
            wsi_path: string, path to WSI file
            mask_path: string, path to mask file in numpy format
            image_size: int, size of the image before splitting into grid, e.g.
                768
            patch_size: int, size of the patch, e.g. 256
            crop_size: int, size of the final crop that is feed into a CNN,
                e.g. 224 for ResNet
            normalize: bool, if normalize the [0, 255] pixel values to [-1, 1],
                mostly False for debuging purpose
            flip: string, 'NONE' or 'FLIP_LEFT_RIGHT' indicating the flip type
            rotate: string, 'NONE' or 'ROTATE_90' or 'ROTATE_180' or
                'ROTATE_270', indicating the rotate type
        """
        self._wsi_path = wsi_path
        self._mask_path = mask_path
        self._image_size = image_size
        self._patch_size = patch_size
        self._crop_size = crop_size
        self._normalize = normalize
        self._flip = flip
        self._rotate = rotate
        self._preprocess()

    def _preprocess(self):
        self._mask = np.load(self._mask_path)
        self._slide = openslide.OpenSlide(self._wsi_path)

        X_slide, Y_slide = self._slide.level_dimensions[0]
        X_mask, Y_mask = self._mask.shape

        if X_slide / X_mask != Y_slide / Y_mask:
            raise Exception('Slide/Mask dimension does not match ,'
                            ' X_slide / X_mask : {} / {},'
                            ' Y_slide / Y_mask : {} / {}'
                            .format(X_slide, X_mask, Y_slide, Y_mask))

        self._resolution = X_slide * 1.0 / X_mask
        if not np.log2(self._resolution).is_integer():
            raise Exception('Resolution (X_slide / X_mask) is not power of 2 :'
                            ' {}'.format(self._resolution))

        # all the idces for tissue region from the tissue mask
        self._X_idcs, self._Y_idcs = np.where(self._mask)
        self._idcs_num = len(self._X_idcs)

        if self._image_size % self._patch_size != 0:
            raise Exception('Image size / patch size != 0 : {} / {}'.
                            format(self._image_size, self._patch_size))
        self._patch_per_side = self._image_size // self._patch_size
        self._grid_size = self._patch_per_side * self._patch_per_side

    def __len__(self):
        return self._idcs_num

    def __getitem__(self, idx):
        x_mask, y_mask = self._X_idcs[idx], self._Y_idcs[idx]

        x_center = int((x_mask + 0.5) * self._resolution)
        y_center = int((y_mask + 0.5) * self._resolution)

        x = int(x_center - self._image_size / 2)
        y = int(y_center - self._image_size / 2)

        img = self._slide.read_region(
            (x, y), 0, (self._image_size, self._image_size)).convert('RGB')

        if self._flip == 'FLIP_LEFT_RIGHT':
            img = img.transpose(PIL.Image.FLIP_LEFT_RIGHT)

        if self._rotate == 'ROTATE_90':
            img = img.transpose(PIL.Image.ROTATE_90)

        if self._rotate == 'ROTATE_180':
            img = img.transpose(PIL.Image.ROTATE_180)

        if self._rotate == 'ROTATE_270':
            img = img.transpose(PIL.Image.ROTATE_270)

        # PIL image:   H x W x C
        # torch image: C X H X W
        img = np.array(img, dtype=np.float32).transpose((2, 0, 1))

        if self._normalize:
            img = (img - 128.0)/128.0

        # flatten the square grid
        img_flat = np.zeros(
            (self._grid_size, 3, self._crop_size, self._crop_size),
            dtype=np.float32)

        idx = 0
        for x_idx in range(self._patch_per_side):
            for y_idx in range(self._patch_per_side):
                # center crop each patch
                x_start = int(
                    (x_idx + 0.5) * self._patch_size - self._crop_size / 2)
                x_end = x_start + self._crop_size
                y_start = int(
                    (y_idx + 0.5) * self._patch_size - self._crop_size / 2)
                y_end = y_start + self._crop_size
                img_flat[idx] = img[:, x_start:x_end, y_start:y_end]

                idx += 1

        return (img_flat, x_mask, y_mask)