# Basic
import sys, os, logging, glob, random, tqdm
os.environ['NUMEXPR_MAX_THREADS'] = '64'
os.environ['NUMEXPR_NUM_THREADS'] = '32'
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath('.')))
sys.path.append(BASE_DIR)
from classfication.utils.config import *
import torch
from torch.optim import *
import torch.nn as nn

try:
    from tensorboardX import SummaryWriter
except ImportError:
    from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from torchvision.models import Inception3
import classfication
from classfication.models.inceptionv3 import inception_v3
from classfication.preprocess.extract_patches import ExtractPatch
from classfication.preprocess.ncrf2dataset import NCRFdata
from classfication.data.dataset import ListDataset
from classfication.utils import Checkpointer
import torch.nn.functional as F
from classfication.train import Train
from collections import OrderedDict
from classfication.data.sampler import RandomSampler
from classfication.postprocess.probs_map import ProbsMap

logging.basicConfig(level=logging.INFO)
# os.environ["CUDA_VISIBLE_DEVICES"] = '0'
workspace = '/userhome/exp_camelyon/dynamic_exp2'
train_model_save = os.path.join(workspace, 'train', 'model')

# 读取数据集
train_table,train_query_hist,train_slide_default = load_table(train128,slides=train_slide)
test_table,test_query_hist,test_slide_default = load_table(test128,slides=test_slide)

# 数据预处理
level = 0
patch_size = 299
crop_size = 299
train_slides = train_slide_default
dataset = ListDataset(TRAINSET, MASK_FOLDER, level, patch_size * pow(2, level), crop_size * pow(2, level), train_table)
train_sampler = classfication.data.sampler.RandomSampler(data_source=dataset, slides=train_slides, num_samples=400000)
valid_slides = {0:train_slide_default[0]}
valid_sampler = classfication.data.sampler.RandomSampler(data_source=dataset, slides=train_slides, num_samples=40000,
                                                         query_hist=train_sampler.query_hist)
batch_size = 32
num_workers = 20
train_dataloader = DataLoader(dataset, batch_size=batch_size, sampler=train_sampler, pin_memory=True,
                              num_workers=num_workers)
valid_dataloader = DataLoader(dataset, batch_size=batch_size, sampler=valid_sampler, pin_memory=True,
                              num_workers=num_workers)

# set model
LR = 0.001
net = nn.DataParallel(Inception3(num_classes=2, aux_logits=False))
out_fn = lambda x: F.softmax(x)[:, 1]
optimizer = SGD(net.parameters(), lr=LR, momentum=0.9)

criterion = nn.CrossEntropyLoss()
### 保存模型
logging.info('load net parameters')
if not os.path.exists(train_model_save):
    raise ValueError('model doesn`t exists!')
start = 134
_ckpter = Checkpointer(train_model_save)
ckpt = _ckpter.load(start)
last_epoch = -1
if ckpt[0]:
    net.load_state_dict(ckpt[0])
    optimizer.load_state_dict(ckpt[1])
    start = ckpt[2] + 1
    last_epoch = ckpt[2]
    for state in optimizer.state.values():
        for k, v in state.items():
            if isinstance(v, torch.Tensor):
                state[k] = v.cuda()
    start = ckpt[2] + 1

net.cuda()

# train with checkpoint
start = 0  # 起始epoch
end = 70
evaluate = True
best_epoch = 0
best_valid_acc = 0
# hard setting
visual = os.path.join(workspace, 'hard', 'visualization')
writer = SummaryWriter(visual)
hard_model_save = os.path.join(workspace, 'hard', 'model')
os.system(f'mkdir -p {hard_model_save} {visual}')
ckpter = Checkpointer(hard_model_save, keep_best=20)
logging.info('set Trainer')
trainer = classfication.train.Train(optimizer, net, workspace, criterion, out_fn)
HN_index = []
for epoch in range(start, end):
    metric = trainer.eval_epoch(train_dataloader)
    HN_index += metric.FP_list
    HP_index = metric.FN_list
    if len(HN_index) == 0:
        continue
    # then you can retrevie them , and save it into csv
    print(f'{len(HN_index)} Hard negtive examples includes')
    HN_table = table.loc[HN_index + train_sampler.sample()].reset_index(drop=True)  # reset dataset
    HN_dataset = ListDataset(TRAINSET, MASK_FOLDER, level, patch_size * pow(2, level), crop_size * pow(2, level),
                             HN_table)
    HN_dataloader = DataLoader(HN_dataset, shuffle=True, batch_size=batch_size, pin_memory=True, num_workers=20)
    metric = trainer.train_epoch(HN_dataloader)
    writer.add_scalar('loss_in_train', metric.get_loss(), epoch)
    writer.add_scalar('ratio_in_train', metric.tumor_ratio(), epoch)
    writer.add_scalar('acc_in_train', metric.get_accuracy(), epoch)
    writer.add_scalar('pre1_in_train', metric.get_precision(), epoch)
    writer.add_scalar('specificity_in_train', metric.get_specificity(), epoch)
    writer.add_scalar('sensitivity_in_train', metric.get_sensitivity(), epoch)
    writer.add_scalar('F1_in_train', metric.get_F1(), epoch)
    writer.add_scalar('HN_in_train', len(HN_index), epoch)
    state_dict = {
        "net": net.state_dict(),
        "optimizer": optimizer.state_dict(),
        "last_epoch": epoch,
    }
    if evaluate:
        metric = trainer.eval_epoch(valid_dataloader)
        writer.add_scalar('ratio_in_valid', metric.tumor_ratio(), epoch)
        writer.add_scalar('acc_in_valid', metric.get_accuracy(), epoch)
        writer.add_scalar('pre1_in_valid', metric.get_precision(), epoch)
        writer.add_scalar('sensitivity_in_valid', metric.get_sensitivity(), epoch)
        writer.add_scalar('specificity_in_valid', metric.get_specificity(), epoch)
        writer.add_scalar('precision2_in_valid', metric.get_precision2(), epoch)
        writer.add_scalar('F1_in_valid', metric.get_F1(), epoch)

        ckpter.save(epoch, state_dict, metric.get_specificity())  # 使用F2寻找最优化模型