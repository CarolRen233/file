import os

basic_dir = '/userhome/exp_camelyon/'
#
expid = 'dynamic_example2'
workspace = os.path.join(basic_dir,expid)
# train
train_space = os.path.join(workspace, 'train')
train_model_save = os.path.join(train_space, 'model')
train_visual = os.path.join(train_space, 'visualization')
