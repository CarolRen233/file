'''
This script check softLabel through GTJSON instead Mask file.
'''
import sys, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(BASE_DIR)
import pandas as pd
from classfication.preprocess.annotation import Annotation
from classfication.utils.config import *

class CheckLabel(object):
    def __init__(self,json_path=GTJSON):
        self._json_path=json_path
        self._pids = list(map(lambda x: x.rstrip('.json'),
                              [i for i in os.listdir(self._json_path) if i.endswith('.json')]))
        self._annotations = {}
        for pid in self._pids:
            pid_json_path = os.path.join(self._json_path, pid + '.json')
            anno = Annotation()
            anno.from_json(pid_json_path)
            self._annotations[pid] = anno

    def check(self,table,win=128):
        assert isinstance(table,pd.DataFrame)
        count = {True:0,False:0}
        for i in table.index:
            pid, _x, _y, target = table.loc[i]
            x_top_left = _x - win//2
            y_top_left = _y - win//2
            label = 0
            for x_idx in range(win):
                for y_idx in range(win):
                    x = x_top_left + x_idx
                    y = y_top_left + y_idx
                    if self._annotations[pid].inside_polygons((x, y), True):
                        label = 1
                        break
            count[label==target]+=1
        return count

    def revise(self,table,save,win=128):
        assert isinstance(table, pd.DataFrame)
        count = {True: 0, False: 0}
        for i in table.index:
            pid, _x, _y, target = table.loc[i]
            x_top_left = _x - win // 2
            y_top_left = _y - win // 2
            label = 0
            for x_idx in range(win):
                for y_idx in range(win):
                    x = x_top_left + x_idx
                    y = y_top_left + y_idx
                    if self._annotations[pid].inside_polygons((x, y), True):
                        label = 1
                        break
            if label != target:
                target.loc[i] = pid, _x, _y, label
            count[label == target] += 1
        print(count)
        if count[False] !=0:
            table.to_csv(save, header=True)

if __name__ == '__main__':
    traintable,_ = load_table(train128,train_slide)
    checker = CheckLabel()
    save = '/userhome/patchlist/revised128'
    os.system(f'mkdir -p {save}')
    savetrain = os.path.join(save, 'traintable.csv')
    checker.revise(traintable,savetrain)
    testtable,_ = load_table(test128,test_slide)
    savetest = os.path.join(save, 'testtable.csv')
    checker.revise(testtable, save)