import sys
import os
import argparse
import logging
import json
import time

import torch
import pandas as pd
import tqdm
try:
    from tensorboardX import SummaryWriter
except ImportError:
    from torch.utils.tensorboard import SummaryWriter
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../')
from  classfication.utils.metrics import *

class Train:
    def __init__(self,optimizer,net,workspace,criterion,out_fn=None):
        self.optimizer = optimizer
        self.net = net
        self.criterion = criterion
        self.out_fn = out_fn
        self.workspace = workspace

    def train_epoch(self,dataloader):
        self.net.train()
        metrics = Metric()
        # qbar=tqdm.tqdm(train_dataloader, dynamic_ncols=True, leave=True)
        for inputs, labels, indexes in dataloader:
            inputs, labels = inputs.cuda(), labels.cuda()
            outputs = self.net(inputs).cuda()
            loss = self.criterion(outputs, labels)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            probs = self.out_fn(outputs)
            metrics.add_data(probs.cpu(), labels.cpu(), indexes,loss)
        print(f'Train Loss:{metrics.get_loss():.4f},acc:{metrics.get_accuracy():.4f},specificity:{metrics.get_specificity():.4f},sensitivity:{metrics.get_sensitivity():.4f}-tumor_ratio:{metrics.tumor_ratio():.4f}')
        return metrics

    def eval_epoch(self,dataloader):
        metrics = Metric()
        self.net.eval()
        # qbar = tqdm.tqdm(dataloader, dynamic_ncols=True, leave=True)
        with torch.no_grad():
            for inputs, labels, indexes  in dataloader:
                inputs, labels = inputs.cuda(), labels.cuda()
                outputs = self.net(inputs)
                loss = self.criterion(outputs, labels)
                probs = self.out_fn(outputs).cpu()
                metrics.add_data(probs.cpu(), labels.cpu(), indexes,loss.cpu())
        print(f'Valid accuracy:{metrics.get_accuracy():.4f}, specificity:{metrics.get_specificity():.4f},sensitivity:{metrics.get_sensitivity():.4f}-tumor_ratio:{metrics.tumor_ratio():.4f}')
        return metrics