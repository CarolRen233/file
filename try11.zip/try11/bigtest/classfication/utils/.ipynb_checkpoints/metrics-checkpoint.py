import os
import numpy as np
import pandas as pd
class Metric:
    r'''all data from torch would be converted into numpy.array. So All you need  is just konwing numpy opration
    '''

    def __init__(self, threshold=0.5):
        self.TP, self.FP, self.TN, self.FN = 0, 0, 0, 0
        self.threshold = threshold
        self.probs = []
        self.indexes = []
        self.FN_list = []
        self.FP_list = []
        self.losses = []

    def add_data(self, probs, target, indexes, loss=0):
        #probs=probs.detach().numpy()
        probs=probs.squeeze()
        predict = probs > self.threshold
        target = target.numpy()
        self.probs += list(probs)
        indexes=indexes.detach().numpy()
        self.indexes += list(indexes)
        #print ('predict.shape',predict.shape)
        #print ('target.shape',target.shape)
        assert predict.shape == target.shape
        if predict.shape == indexes.shape:
            self.FP_list += list(indexes[(predict == 1) * (target == 0)])
            self.FN_list += list(indexes[(predict == 0) * (target == 1)])
        self.TP += np.sum((predict == 1) * (target == 1))
        self.FP += np.sum((predict == 1) * (target == 0))
        self.TN += np.sum((predict == 0) * (target == 0))
        self.FN += np.sum((predict == 0) * (target == 1))
        self.losses.append(loss)

    def get_loss(self):
        return np.sum(self.losses) / len(self.losses)

    def get_accuracy(self):
        return (self.TP + self.TN) / (self.TP + self.TN + self.FP + self.FN + 1e-6)

    def get_sensitivity(self):
        return self.TP / (self.TP + self.FN + 1e-6)

    def get_specificity(self):
        return self.TN / (self.TN + self.FP + 1e-6)

    def get_precision(self):
        return self.TP / (self.TP + self.FP + 1e-6)

    def get_precision2(self):
        return (self.TN) / (self.TN + self.FN + 1e-6)

    def get_F1(self):
        SE = self.get_sensitivity()
        PC = self.get_precision()
        return 2 * SE * PC / (SE + PC + 1e-6)

    def tumor_ratio(self):
        return (self.FN + self.TP) / (self.TP + self.TN + self.FP + self.FN)

class MetricTable:
    r'''all metric data would be saved and viuslization'''
    def __init__(self,save):
        self.save = save
        self.save_table = (os.path.join(self.save,'metric.csv'))
        self.table = self.load_table()

    def load_table(self):
        if os.path.exists(self.save_table):
            return pd.read_csv(self.save_table,header=0)
        print(f'{self.save_table} not exists!')
        table = pd.DataFrame(columns=['accuracy','sensitivity','specificity','precision','precision2','F1','loss'])
        return table

    def add_metric(self,metric,epoch):
        r'''save metric into csv'''
        self.table.loc[epoch]=(metric.get_accuracy(),metric.get_sensitivity(),metric.get_specificity(),metric.get_precision(),metric.get_precision2(),metric.get_F1(),metric.get_loss())
        np.save(os.path.join(self.save,f'{epoch}.npy'),np.array([metric.indexes,metric.probs]))
        self.table.to_csv(self.save_table, header=True)