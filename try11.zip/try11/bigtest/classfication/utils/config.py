import os, sys, json, glob, tqdm
import pandas as pd

#os.environ['NUMEXPR_MAX_THREADS'] = '64'
#os.environ['NUMEXPR_NUM_THREADS'] = '64'

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(BASE_DIR)

#  Cameyon16 DataSet config
TRAINSET = '/userhome/dataset/CAMELYON16/training/'
TESTSET = '/userhome/dataset/CAMELYON16/testing/'
MASK_FOLDER = '/userhome/dataset/CAMELYON16/all_mask/'
GTJSON = '/userhome/dataset/CAMELYON16/ground_truth'
TRAINANNO = os.path.join(TRAINSET, 'lesion_annotations')
TESTSETANNO = os.path.join(TESTSET, 'lesion_annotations')
camelyon17_type_mask = False

# Patch list
#test128 = '/userhome/output/p4m/dataset/patchlist/test128_1/patchlist'
#train128 = '/root/docker_share/dataset/CAMELYON16/patchlist/trainset128'
#ncrf = '/userhome/data_camelyon/patchlist/ncrf'

def load_ncrf():
    trainset =pd.read_csv(os.path.join(ncrf,'ncrf_train.csv'), index_col=0, header=0)
    validset =pd.read_csv(os.path.join(ncrf,'ncrf_valid.csv'), index_col=0, header=0)
    return trainset,validset

# config
def skip_slide(slide_name):
    skip_list = ['normal_86', 'normal_144', 'test_049', 'test_114']
    for skip_name in skip_list:
        if skip_name in slide_name:
            return True
    return False

train_slide = {}
train_slide[1] = [os.path.basename(tif).rstrip('.tif') for tif in glob.glob(os.path.join(TRAINSET, 'tumor', '*.tif')) if not skip_slide(tif) ]
train_slide[0] = [os.path.basename(tif).rstrip('.tif') for tif in glob.glob(os.path.join(TRAINSET, 'normal', '*.tif')) if not skip_slide(tif)]
test_slide = {}
test_slide[1] = [os.path.basename(xml).rstrip('.xml') for xml in
                 glob.glob(os.path.join(TESTSET, 'lesion_annotations', '*.xml')) if not skip_slide(xml) ]
test_slide[0] = [os.path.basename(tif).rstrip('.tif') for tif in glob.glob(os.path.join(TESTSET, 'images', '*.tif')) if
                  tif not in test_slide[1] and not skip_slide(tif)]



# load data
def load_table(patchlist, slides, labels=[0, 1]):
    normal_csv = [os.path.join(patchlist, f'{slide}.csv') for slide in slides[0]]
    tumor_csv = [os.path.join(patchlist, f'{slide}.csv') for slide in slides[1]]
    csv_list = normal_csv + tumor_csv
    csv_list.sort()
    tables = []
    qbar = tqdm.tqdm(csv_list)
    # 此处从生成的patch的csv文件中导入，如果调用extractor，则是从返回值获取即可
    for csv in qbar:
        qbar.set_description(f'loading csv: {csv}')
        tables.append(pd.read_csv(csv, index_col=0, header=0))
    table = pd.concat(tables).reset_index(drop=True)
    sorted_query_hist = os.path.join(patchlist, 'sorted_query_hist.json')
    try:
        with open(sorted_query_hist, 'r')as f:
            query_hist = json.load(f)
    except:
        print(f'warning: can`t open{sorted_query_hist},now generate it!')
        query_hist = {}
        query_slides = {}
        query_slides[0] = slides[0] + slides[1]
        query_slides[1] = slides[1]
        for label in labels:
            query = table.query(f'(label=={label})')
            for slide in query_slides[label]:
                indexes = query[query['slide_name'] == slide].index
                query_hist[f'{slide}_{label}'] = indexes.tolist()
        with open(sorted_query_hist, 'w') as f:
            json.dump(query_hist, f)
    return table, query_hist