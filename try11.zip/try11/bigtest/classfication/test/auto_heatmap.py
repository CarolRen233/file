# Basic
import sys, os, logging, time
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(BASE_DIR)
from classfication.utils.config import *
from classfication.postprocess.nms import NMS
import  numpy as np

try:
    from tensorboardX import SummaryWriter
except ImportError:
    from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from classfication.data.dataset import ListDataset
from classfication.utils import Checkpointer

from classfication.postprocess.probs_map import ProbsMap
from classfication.postprocess.froc import Analysis
# 加载实验参数
from classfication.test.config import *
train_writer=SummaryWriter(train_visual)
ckpter = Checkpointer(train_model_save)
logging.basicConfig(level=logging.INFO, filename=os.path.join(train_space, 'auto_heatmap_log.txt'))


def find_last_epoch(train_model_save):
    epochs = []
    for ckpt in sorted(glob.glob(os.path.join(train_model_save, 'checkpoint_*.pt'))):
        epochs.append(int(ckpt.split('.')[0].split('_')[-1]))
    if len(epochs)==0:
        return -1
    return max(epochs)

# 加载测试集
level = 0
patch_size = 299
crop_size = 299
grid_size = 128
batch_size = 128
num_workers = 20
test_table,test_query_hist = load_table(test128, slides=test_slide)
dataset = ListDataset(TESTSET, MASK_FOLDER, level, patch_size * pow(2, level), crop_size * pow(2, level), test_table)
test_dataloader = DataLoader(dataset, batch_size=batch_size, num_workers=num_workers, shuffle=False,
                                 drop_last=False)

# set NMS
radius=6
nms = NMS(level=7, radius=radius, sigma=0, prob_thred=0.5)
epoch=30
analysis = Analysis
while True:
    last_epoch = find_last_epoch(train_model_save)  # 选择需要的epoch
    if last_epoch == -1 or epoch >last_epoch:
        time.sleep(3600)
        continue
    heatmap_folder = os.path.join(train_space, str(epoch), f'heatmap128_random')
    print(f'save:{heatmap_folder}')
    if os.path.exists(heatmap_folder):
        epoch += 5
        continue
    ckpt = ckpter.load(epoch)
    net.load_state_dict(ckpt[0])
    net.cuda()
    os.system(f'mkdir -p {heatmap_folder}')
    heatmap = ProbsMap(dataset, test_dataloader, heatmap_folder, net, grid_size, out_fn, tif_folder=TESTSET)
    heatmap.gen_heatmap()
    csv_folder = os.path.join(heatmap_folder, f'csv_{radius}')
    if not os.path.exists(csv_folder):
        os.system(f'mkdir -p  {csv_folder}')
    for npy in glob.glob(os.path.join(heatmap_folder, '*.npy')):
        basename = os.path.basename(npy).rstrip('.npy')
        save = os.path.join(csv_folder, basename + '.csv')
        heatmap = np.load(npy)
        nms.run(heatmap, save)
    froc = analysis.froc(csv_folder)
    print(f'epoch {epoch} FROC:{froc}')
    train_writer.add_scalar('FROC',froc,epoch)