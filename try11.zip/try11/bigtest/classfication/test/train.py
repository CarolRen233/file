import sys,os,logging
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath('.')))
sys.path.append(BASE_DIR)
from classfication.utils.config import *
from torch.optim import *
import torch.nn as nn
try:
    from tensorboardX import SummaryWriter
except ImportError:
    from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader

from classfication.data.dataset import ListDataset
from classfication.utils import Checkpointer,MetricTable

from classfication.train import Train
from classfication.data.sampler import RandomSampler
from classfication.test.config import *
logging.basicConfig(level=logging.INFO)
'''
仅使用trainset用于valid,但是结果看起来在测试集上的表现差异较大
'''

# 读取数据集
train_table,train_query_hist = load_table(train128,slides=train_slide)
test_table,test_query_hist = load_table(test128,slides=test_slide)
# 数据预处理
level = 0
patch_size = 299
crop_size = 299

def normal_skip(key):
    return ~(key in  ['tumor_015', 'tumor_018', 'tumor_020', 'tumor_029','tumor_033', 'tumor_044', 'tumor_046', 'tumor_051', 'tumor_054', 'tumor_055', 'tumor_079', 'tumor_092', 'tumor_095'])

train_slide[0] = [slide  for slide in train_slide[0] + train_slide[1] if normal_skip(slide)]
Trainset = ListDataset(TRAINSET,MASK_FOLDER,level,patch_size * pow(2,level), crop_size * pow(2,level),train_table)
train_sampler = RandomSampler(data_source=Trainset,slides=train_slide,num_samples=400000,query_hist=train_query_hist)
# 使用测试集作为验证
Testset = ListDataset(TESTSET,MASK_FOLDER,level,patch_size * pow(2,level), crop_size * pow(2,level),test_table)
valid_sampler = RandomSampler(data_source=Trainset, slides=train_slide, num_samples=40000, query_hist=test_query_hist)

#set model

batch_size = 32
num_workers = 20
net = nn.DataParallel(SlimInception3(num_classes=2))
out_fn = lambda x:F.softmax(x)[:,1]
train_dataloader = DataLoader(Trainset, batch_size=batch_size, sampler=train_sampler, num_workers=num_workers)
valid_dataloader =  DataLoader(Testset, batch_size=batch_size, sampler=valid_sampler, num_workers=num_workers)
optimizer=SGD(net.parameters(),lr=0.001,momentum=0.9)
start = 0 #    起始epoch
end = 700
evaluate = True
criterion = nn.CrossEntropyLoss()

metrictable = MetricTable(os.path.join(train_space,'metric'))
#  ===================no need change===================
### 保存模型
logging.info('load net parameters')
if not os.path.exists(train_model_save):
    os.system(f"mkdir -p {train_model_save} {train_visual}")
ckpter = Checkpointer(train_model_save,keep_best=20, keep_last=20,remove=False)

train_writer=SummaryWriter(train_visual)
net.cuda()

# train with checkpoint
best_epoch = 0
best_valid_acc = 0
logging.info('set Trainer')
trainer = Train(optimizer, net, workspace, criterion, out_fn)
for epoch in range(start, end):
    metric = trainer.train_epoch(train_dataloader)
    lr=optimizer.state_dict()['param_groups'][0]['lr']
    train_writer.add_scalar('learning_rate_in_train', lr, epoch)
    train_writer.add_scalar('loss_in_train', metric.get_loss(), epoch)
    train_writer.add_scalar('ratio_in_train', metric.tumor_ratio(), epoch)
    train_writer.add_scalar('acc_in_train', metric.get_accuracy(), epoch)
    train_writer.add_scalar('pre1_in_train',metric.get_precision(),epoch)
    train_writer.add_scalar('pre2_in_train', metric.get_precision2(), epoch)
    train_writer.add_scalar('specificity_in_train', metric.get_specificity(), epoch)
    train_writer.add_scalar('sensitivity_in_train', metric.get_sensitivity(), epoch)
    train_writer.add_scalar('F1_in_train',metric.get_F1(), epoch)
    state_dict = {
        "net": net.state_dict(),
        "optimizer": optimizer.state_dict(),
        "last_epoch": epoch,
    }
    if evaluate:
        metric = trainer.eval_epoch(valid_dataloader)
        train_writer.add_scalar('ratio_in_valid', metric.tumor_ratio(), epoch)
        train_writer.add_scalar('acc_in_valid', metric.get_accuracy(), epoch)
        train_writer.add_scalar('pre1_in_valid',metric.get_precision(),epoch)
        train_writer.add_scalar('pre2_in_valid', metric.get_sensitivity(), epoch)
        train_writer.add_scalar('loss_in_valid', metric.get_precision2(), epoch)
        train_writer.add_scalar('sensitivity_in_valid', metric.get_sensitivity(), epoch)
        train_writer.add_scalar('specificity_in_vaiid', metric.get_specificity(), epoch)
        train_writer.add_scalar('F1_in_valid',metric.get_F1(), epoch)
        total_acc=metric.get_accuracy()
        ckpter.save(epoch, state_dict, total_acc)
        if total_acc > best_valid_acc:
            best_epoch = epoch
            best_valid_acc = total_acc
    else:
        ckpter.save(epoch, state_dict,metric.get_accuracy())
    metrictable.add_metric(metric,epoch)