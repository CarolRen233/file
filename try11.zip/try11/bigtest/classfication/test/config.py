import os
import torch.nn as nn
from classfication.models.inceptionv3 import SlimInception3
import torch.nn.functional as F
# set path
basic_dir = '/userhome/exp_camelyon/'
expid = 'test'
workspace = os.path.join(basic_dir,expid)
## set train path
train_space = os.path.join(workspace, 'train')
train_model_save = os.path.join(train_space, 'model')
train_visual = os.path.join(train_space, 'visualization')

# set model
net = nn.DataParallel(SlimInception3(num_classes=2))
out_fn = lambda x: F.softmax(x)[:, 1]
