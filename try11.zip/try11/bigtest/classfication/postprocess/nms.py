import numpy as np
from skimage import filters
class NMS(object):
    def __init__(self,level,radius=12,sigma=0,prob_thred=0.5):
        '''
        设置通用NMS处理代码
        :param level:
        :param radius:
        :param sigma:
        :param prob_thred:
        '''
        self.level=level
        self.radius=radius
        self.sigma=sigma
        self.prob_thred=prob_thred
    def run(self,probs_map,output_path):
        '''

        :param probs_map_path: heatmap的路径
        :param output_path:  保存为csv坐标
        :return:
        '''
        X, Y = probs_map.shape
        mag=pow(2,self.level)
        if self.sigma>0:
            probs_map = filters.gaussian(probs_map, sigma=self.sigma)
        outfile= open(output_path,'w')
        while np.max(probs_map) > self.prob_thred:
            prob_max = probs_map.max()
            max_idx = np.where(probs_map == prob_max)
            r_mask, c_mask = max_idx[0][0], max_idx[1][0]
            y_wsi = int((r_mask + 0.5) * mag) # 矩阵的行列转换成xy坐标
            x_wsi = int((c_mask + 0.5) * mag)
            outfile.write('{:0.5f},{},{}'.format(prob_max, x_wsi, y_wsi) + '\n')
            x_min = r_mask - self.radius if r_mask - self.radius > 0 else 0
            x_max = r_mask + self.radius if r_mask + self.radius <= X else X
            y_min = c_mask - self.radius if c_mask - self.radius > 0 else 0
            y_max = c_mask + self.radius if c_mask + self.radius <= Y else Y

            for x in range(x_min, x_max):
                for y in range(y_min, y_max):
                    probs_map[x, y] = 0
        outfile.close()
