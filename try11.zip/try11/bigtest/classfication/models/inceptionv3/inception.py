from collections import namedtuple
import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch import Tensor


class SlimInception3(nn.Module):

    def __init__(self, num_classes=2,  transform_input=False,depth_multiplier=0.1,min_depth=16,
                 inception_blocks=None, init_weights=True):
        super(SlimInception3, self).__init__()
        if inception_blocks is None:
            inception_blocks = [
                BasicConv2d, InceptionA, InceptionB, InceptionC,
                InceptionD, InceptionE
            ]
        assert len(inception_blocks) == 6
        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        conv_block = inception_blocks[0]
        inception_a = inception_blocks[1]
        inception_b = inception_blocks[2]
        inception_c = inception_blocks[3]
        inception_d = inception_blocks[4]
        inception_e = inception_blocks[5]


        self.transform_input = transform_input
        self.Conv2d_1a_3x3 = conv_block(3, depth(32), kernel_size=3, stride=2,)
        self.Conv2d_2a_3x3 = conv_block(depth(32), depth(32), kernel_size=3)
        self.Conv2d_2b_3x3 = conv_block(depth(32), depth(64), kernel_size=3, padding=1)
        self.Conv2d_3b_1x1 = conv_block(depth(64), depth(80), kernel_size=1)
        self.Conv2d_4a_3x3 = conv_block(depth(80), depth(192), kernel_size=3)
        self.Mixed_5b = inception_a(depth(192), pool_features=depth(32),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_5c = inception_a(64, pool_features=depth(64),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_5d = inception_a(64, pool_features=depth(64),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_6a = inception_b(64,depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_6b = inception_c(118, channels_7x7=depth(128),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_6c = inception_c(depth(768), channels_7x7=depth(160),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_6d = inception_c(depth(768), channels_7x7=depth(160),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_6e = inception_c(depth(768), channels_7x7=depth(192),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_7a = inception_d(depth(768),depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_7b = inception_e(127,depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.Mixed_7c = inception_e(203,depth_multiplier=depth_multiplier,min_depth=min_depth)
        self.fc = nn.Linear(203, num_classes)
        if init_weights:
            for m in self.modules():
                if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                    import scipy.stats as stats
                    stddev = m.stddev if hasattr(m, 'stddev') else 0.1
                    X = stats.truncnorm(-2, 2, scale=stddev)
                    values = torch.as_tensor(X.rvs(m.weight.numel()), dtype=m.weight.dtype)
                    values = values.view(m.weight.size())
                    with torch.no_grad():
                        m.weight.copy_(values)
                elif isinstance(m, nn.BatchNorm2d):
                    nn.init.constant_(m.weight, 1)
                    nn.init.constant_(m.bias, 0)

    def _transform_input(self, x):
        if self.transform_input:
            x_ch0 = torch.unsqueeze(x[:, 0], 1) * (0.229 / 0.5) + (0.485 - 0.5) / 0.5
            x_ch1 = torch.unsqueeze(x[:, 1], 1) * (0.224 / 0.5) + (0.456 - 0.5) / 0.5
            x_ch2 = torch.unsqueeze(x[:, 2], 1) * (0.225 / 0.5) + (0.406 - 0.5) / 0.5
            x = torch.cat((x_ch0, x_ch1, x_ch2), 1)
        return x

    def _forward(self, x):
        # N x 3 x 299 x 299
        # print(x.shape)
        x = self.Conv2d_1a_3x3(x)
        # N x 32 x 149 x 149
        # print(x.shape,'Conv2d_1a_3x3')
        x = self.Conv2d_2a_3x3(x)
        # N x 32 x 147 x 147
        # print(x.shape,'Conv2d_2a_3x3')
        x = self.Conv2d_2b_3x3(x)
        # N x 64 x 147 x 147
        # print(x.shape,'Conv2d_2b_3x3')
        x = F.max_pool2d(x, kernel_size=3, stride=2)
        # N x 64 x 73 x 73
        # print(x.shape,'max_pool2d')
        x = self.Conv2d_3b_1x1(x)
        # N x 80 x 73 x 73
        # print(x.shape,'Conv2d_3b_1x1')
        x = self.Conv2d_4a_3x3(x)
        # N x 192 x 71 x 71
        # print(x.shape,'Conv2d_4a_3x3')
        x = F.max_pool2d(x, kernel_size=3, stride=2)
        # N x 192 x 35 x 35
        # print(x.shape,'max_pool2d')
        x = self.Mixed_5b(x)
        # print(x.shape,'Mixed_5b')
        # N x 256 x 35 x 35
        x = self.Mixed_5c(x)
        # print(x.shape,'Mixed_5c')
        # N x 288 x 35 x 35
        x = self.Mixed_5d(x)
        # print(x.shape,'Mixed_5d')
        # N x 288 x 35 x 35
        x = self.Mixed_6a(x)
        # print(x.shape,'Mixed_6a')
        # N x 768 x 17 x 17
        x = self.Mixed_6b(x)
        # print(x.shape,'Mixed_6b')
        # N x 768 x 17 x 17
        x = self.Mixed_6c(x)
        # print(x.shape,'Mixed_6c')
        # N x 768 x 17 x 17
        x = self.Mixed_6d(x)
        # print(x.shape,'Mixed_6d')
        # N x 768 x 17 x 17
        x = self.Mixed_6e(x)
        # print(x.shape,'Mixed_6e')
        # N x 768 x 17 x 17
        x = self.Mixed_7a(x)
        # print(x.shape,'Mixed_7a')
        # N x 1280 x 8 x 8
        x = self.Mixed_7b(x)
        # print(x.shape,'Mixed_7b')
        # N x 2048 x 8 x 8
        x = self.Mixed_7c(x)
        # print(x.shape,'Mixed_7c')
        # N x 2048 x 8 x 8
        # Adaptive average pooling
        x = F.adaptive_avg_pool2d(x, (1, 1))
        # print(x.shape,'adaptive_avg_pool2d')
        # N x 2048 x 1 x 1
        x = F.dropout(x, training=self.training)
        # print(x.shape,'dropout')
        # N x 2048 x 1 x 1
        x = torch.flatten(x, 1)
        # print(x.shape,'flatten')
        # N x 2048
        x = self.fc(x)
        # print(x.shape,'fc')
        # N x 1000 (num_classes)
        return x


    def forward(self, x):
        x = self._transform_input(x)
        x = self._forward(x)
        return x


class InceptionA(nn.Module):

    def __init__(self, in_channels, pool_features,depth_multiplier=1,min_depth=16, conv_block=None):
        super(InceptionA, self).__init__()
        if conv_block is None:
            conv_block = BasicConv2d

        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        self.branch1x1 = conv_block(in_channels, depth(64), kernel_size=1)

        self.branch5x5_1 = conv_block(in_channels, depth(48), kernel_size=1)
        self.branch5x5_2 = conv_block(depth(48), depth(64), kernel_size=5, padding=2)

        self.branch3x3dbl_1 = conv_block(in_channels, depth(64), kernel_size=1)
        self.branch3x3dbl_2 = conv_block(depth(64), depth(96), kernel_size=3, padding=1)
        self.branch3x3dbl_3 = conv_block(depth(96), depth(96), kernel_size=3, padding=1)

        self.branch_pool = conv_block(in_channels, pool_features, kernel_size=1)

    def _forward(self, x):
        branch1x1 = self.branch1x1(x)
        branch5x5 = self.branch5x5_1(x)
        branch5x5 = self.branch5x5_2(branch5x5)

        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = self.branch3x3dbl_3(branch3x3dbl)

        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)

        outputs = [branch1x1, branch5x5, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x):
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionB(nn.Module):

    def __init__(self, in_channels,depth_multiplier=1,min_depth=16, conv_block=None):
        super(InceptionB, self).__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        self.branch3x3 = conv_block(in_channels, depth(384), kernel_size=3, stride=2)

        self.branch3x3dbl_1 = conv_block(in_channels, depth(64), kernel_size=1)
        self.branch3x3dbl_2 = conv_block(depth(64), depth(96), kernel_size=3, padding=1)
        self.branch3x3dbl_3 = conv_block(depth(96), depth(96), kernel_size=3, stride=2)

    def _forward(self, x):
        branch3x3 = self.branch3x3(x)

        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = self.branch3x3dbl_3(branch3x3dbl)

        branch_pool = F.max_pool2d(x, kernel_size=3, stride=2)

        outputs = [branch3x3, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x):
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionC(nn.Module):

    def __init__(self, in_channels, channels_7x7,depth_multiplier=1,min_depth=16, conv_block=None):
        super(InceptionC, self).__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        self.branch1x1 = conv_block(in_channels, depth(192), kernel_size=1)
        c7 = channels_7x7
        self.branch7x7_1 = conv_block(in_channels, c7, kernel_size=1)
        self.branch7x7_2 = conv_block(c7, c7, kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7_3 = conv_block(c7, depth(192), kernel_size=(7, 1), padding=(3, 0))

        self.branch7x7dbl_1 = conv_block(in_channels, c7, kernel_size=1)
        self.branch7x7dbl_2 = conv_block(c7, c7, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7dbl_3 = conv_block(c7, c7, kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7dbl_4 = conv_block(c7, c7, kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7dbl_5 = conv_block(c7, depth(192), kernel_size=(1, 7), padding=(0, 3))

        self.branch_pool = conv_block(in_channels, depth(192), kernel_size=1)

    def _forward(self, x):
        branch1x1 = self.branch1x1(x)

        branch7x7 = self.branch7x7_1(x)
        branch7x7 = self.branch7x7_2(branch7x7)
        branch7x7 = self.branch7x7_3(branch7x7)

        branch7x7dbl = self.branch7x7dbl_1(x)
        branch7x7dbl = self.branch7x7dbl_2(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_3(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_4(branch7x7dbl)
        branch7x7dbl = self.branch7x7dbl_5(branch7x7dbl)

        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)

        outputs = [branch1x1, branch7x7, branch7x7dbl, branch_pool]
        return outputs

    def forward(self, x):
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionD(nn.Module):

    def __init__(self, in_channels, depth_multiplier=1,min_depth=16, conv_block=None):
        super(InceptionD, self).__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        self.branch3x3_1 = conv_block(in_channels, depth(192), kernel_size=1)
        self.branch3x3_2 = conv_block(depth(192), depth(320), kernel_size=3, stride=2)

        self.branch7x7x3_1 = conv_block(in_channels, depth(192), kernel_size=1)
        self.branch7x7x3_2 = conv_block(depth(192), depth(192), kernel_size=(1, 7), padding=(0, 3))
        self.branch7x7x3_3 = conv_block(depth(192), depth(192), kernel_size=(7, 1), padding=(3, 0))
        self.branch7x7x3_4 = conv_block(depth(192), depth(192), kernel_size=3, stride=2)

    def _forward(self, x):
        branch3x3 = self.branch3x3_1(x)
        branch3x3 = self.branch3x3_2(branch3x3)

        branch7x7x3 = self.branch7x7x3_1(x)
        branch7x7x3 = self.branch7x7x3_2(branch7x7x3)
        branch7x7x3 = self.branch7x7x3_3(branch7x7x3)
        branch7x7x3 = self.branch7x7x3_4(branch7x7x3)

        branch_pool = F.max_pool2d(x, kernel_size=3, stride=2)
        outputs = [branch3x3, branch7x7x3, branch_pool]
        return outputs

    def forward(self, x):
        outputs = self._forward(x)
        return torch.cat(outputs, 1)


class InceptionE(nn.Module):

    def __init__(self, in_channels, depth_multiplier=1,min_depth=16, conv_block=None):
        super(InceptionE, self).__init__()
        if conv_block is None:
            conv_block = BasicConv2d
        depth = lambda d: max(int(d * depth_multiplier), min_depth)
        self.branch1x1 = conv_block(in_channels, depth(320), kernel_size=1)

        self.branch3x3_1 = conv_block(in_channels, depth(384), kernel_size=1)
        self.branch3x3_2a = conv_block(depth(384), depth(384), kernel_size=(1, 3), padding=(0, 1))
        self.branch3x3_2b = conv_block(depth(384), depth(384), kernel_size=(3, 1), padding=(1, 0))

        self.branch3x3dbl_1 = conv_block(in_channels, depth(448), kernel_size=1)
        self.branch3x3dbl_2 = conv_block(depth(448), depth(384), kernel_size=3, padding=1)
        self.branch3x3dbl_3a = conv_block(depth(384), depth(384), kernel_size=(1, 3), padding=(0, 1))
        self.branch3x3dbl_3b = conv_block(depth(384), depth(384), kernel_size=(3, 1), padding=(1, 0))

        self.branch_pool = conv_block(in_channels, depth(192), kernel_size=1)

    def _forward(self, x):
        branch1x1 = self.branch1x1(x)

        branch3x3 = self.branch3x3_1(x)
        branch3x3 = [
            self.branch3x3_2a(branch3x3),
            self.branch3x3_2b(branch3x3),
        ]
        branch3x3 = torch.cat(branch3x3, 1)

        branch3x3dbl = self.branch3x3dbl_1(x)
        branch3x3dbl = self.branch3x3dbl_2(branch3x3dbl)
        branch3x3dbl = [
            self.branch3x3dbl_3a(branch3x3dbl),
            self.branch3x3dbl_3b(branch3x3dbl),
        ]
        branch3x3dbl = torch.cat(branch3x3dbl, 1)

        branch_pool = F.avg_pool2d(x, kernel_size=3, stride=1, padding=1)
        branch_pool = self.branch_pool(branch_pool)

        outputs = [branch1x1, branch3x3, branch3x3dbl, branch_pool]
        return outputs

    def forward(self, x):
        outputs = self._forward(x)
        return torch.cat(outputs, 1)



class BasicConv2d(nn.Module):

    def __init__(self, in_channels, out_channels, **kwargs):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, bias=False, **kwargs)
        self.bn = nn.BatchNorm2d(out_channels, eps=0.001)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return F.relu(x, inplace=True)

if __name__=='__main__':
    model = Inception3(num_classes=2,depth_multiplier=0.1)
    input =torch.rand(((3,3,299,299)))
    print('input size:',input.shape)
    output=model(input)
#     print('output size:',output.shape)