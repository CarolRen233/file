import sys
import os
import argparse
from openslide import open_slide, __library_version__ as openslide_lib_version, __version__ as openslide_version
import pandas as pd
import logging
import time
from shutil import copyfile
from generate_patch import *


parser = argparse.ArgumentParser(description='Generate patches from a given '
                                             'list of coordinates')

parser.add_argument('csv_list',default='/userhome/output/p4m/dataset/patchlist/train_patch/train_patchlist/csv_list.txt',type=str, help='patchlist csv list')
parser.add_argument('patchlist_path',default='/userhome/output/p4m/dataset/patchlist/train_patch/train_patchlist',type=str,help='Path to the patchlist directory ')
parser.add_argument('npy_save_folder',
                    default='/userhome/output/p4m/dataset/patchlist/train_patch/patch/',
                    type=str,
                    help='Path to the output directory of patch images')
parser.add_argument('--patch_size', default=96, type=int, help='patch size, '
                                                               'default 96')
parser.add_argument('--patch_centre', default=32, type=int, help='patch_centre, '
                                                                 'default 32')
parser.add_argument('--lev', default=2, type=int, help='level for WSI, to '
                                                       'generate patches, default 2')





def run(args):
    logging.basicConfig(level=logging.INFO, filename=os.path.join(args.npy_save_folder, 'patch_generate_log.txt'))
    logging.info(str(args))

    if not os.path.exists(args.npy_save_folder):
        os.mkdir(args.npy_save_folder)

    infile = open(args.csv_list)
    opts_list = []
    for i, line in enumerate(infile):
        csv = line.strip('\n')
        print ('---processing--csv,',csv)
        
        tumor_patches, normal_patches = [], []
        tumor_labels, normal_labels = [], []

        basename = os.path.basename(csv)
        name = basename.split('.')[0]
        logging.info(f'------------------------{name}-------------------------')
        print ('name',name)
        if 'tumor' in name:
            slide_path = '/userhome/dataset/CAMELYON16/training/tumor'
            is_tumor = True
        elif 'normal' in name:
            slide_path = '/userhome/dataset/CAMELYON16/training/normal'
            is_tumor = False
        mask_path = '/userhome/dataset/CAMELYON16/train_mask'
        slide = open_slide(os.path.join(slide_path,name + '.tif'))
        mask =open_slide(os.path.join(mask_path,name + '.tif'))

        patchlist = pd.read_csv(os.path.join(csv))
   
        for row in patchlist.head(200).itertuples():
            x0 = getattr(row, 'x')
            y0 = getattr(row, 'y')
            patch_image_lev2, patch_mask_lev2, patch_tissue_lev2 = \
                get_patches(slide, mask, args.lev, x0, y0, args.patch_size)
            #tissue_ratio = np.sum(patch_tissue_lev2[:, :, 0]) / (args.patch_size ** 2)
            #print ('tissue_ratio',tissue_ratio)
            has_cancer = False
            if True:   #if tissue_ratio > 0.5: 结果所有的ratio=0.0
                #print ('tissue ratio!')
                if is_tumor:
                    has_cancer = check_patch_centre(patch_mask_lev2, args.patch_centre)
                    if has_cancer:
                        tumor_patches.append(patch_image_lev2)
                        tumor_labels.append(1)
                    else:
                        normal_patches.append(patch_image_lev2)
                        normal_labels.append(0)
                    continue
                normal_patches.append(patch_image_lev2)
                normal_labels.append(0)

        assert len(tumor_labels)==len(tumor_patches)
        X_tumor = np.asarray(tumor_patches)
        y_tumor = np.asarray(tumor_labels)

        assert len(normal_labels)==len(normal_patches)
        X_normal = np.asarray(normal_patches)
        y_normal = np.asarray(normal_labels)

        if is_tumor:
            X_tumor_filename = args.npy_save_folder + name + '-X_tumor-lev' + \
                               str(args.lev) + '-' + str(args.patch_size) + '-' + str(len(tumor_labels))
            y_tumor_filename = args.npy_save_folder + name + '-y_tumor-lev' + \
                               str(args.lev) + '-' + str(args.patch_size) + '-' + str(len(tumor_labels))
            np.save(X_tumor_filename, X_tumor)
            np.save(y_tumor_filename,y_tumor)

        X_normal_filename = args.npy_save_folder + name + '-X_normal-lev' + \
                           str(args.lev) + '-' + str(args.patch_size) + '-' + str(len(normal_labels))
        y_normal_filename = args.npy_save_folder + name + '-y_normal-lev' + \
                           str(args.lev) + '-' + str(args.patch_size) + '-' + str(len(normal_labels))
        np.save(X_normal_filename,X_normal)
        np.save(y_normal_filename,y_normal)

    




def main():
    args = parser.parse_args()
    run(args)


if __name__ == '__main__':
    main()